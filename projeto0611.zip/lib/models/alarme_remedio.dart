import 'package:flutter/material.dart';

class AlarmeRemedio extends StatefulWidget {
  const AlarmeRemedio({super.key});

  @override
  State<AlarmeRemedio> createState() => _AlarmeRemedioState();
}

class _AlarmeRemedioState extends State<AlarmeRemedio> {
  @override
  Widget build(BuildContext context) {
    return const Placeholder();
  }
}